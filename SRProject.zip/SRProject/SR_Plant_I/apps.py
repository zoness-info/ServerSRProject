from django.apps import AppConfig


class SrPlantIConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SR_Plant_I'
